# Shoppy Dashboard

### React Admin Dashboard App With Theming, Tables, Charts, Calendar, Kanban and More. This Admin Panel includes one Dashboard, Three Pages, Four Apps, and Seven fully functional charts!

- Responsive Website Using React JS, Syncfusion, and Tailwind CSS.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

## [Website Demo](https://shoppy-admin-dashboard.vercel.app/)

![screencapture-shoppy-admin-dashboard-vercel-app-2022-09-16-23_03_55](https://user-images.githubusercontent.com/62913154/190741579-c0a2039d-8824-4acf-8a07-e3fb6e2fd2fc.png)
